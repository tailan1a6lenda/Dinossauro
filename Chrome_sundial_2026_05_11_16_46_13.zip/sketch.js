let x, y;

function setup() {
  createCanvas(400, 400);
  x = int(random(400));
  y = int(random(400));
}

function draw() {
  let distancia = dist(mouseX, mouseY, x, y);
  let maxDist = dist(0, 0, width, height);

  let r = map(distancia, 0, maxDist, 0, 255);
  let b = map(distancia, 0, maxDist, 255, 0);

  background(220);

  fill(r, 0, b);
  square(mouseX - 10, mouseY - 10, 20);

  x = constrain(x + random(-5, 5), 0, width);
  y = constrain(y + random(-5, 5), 0, height);

  if (distancia < 20) {
    fill('red');
    text('Achou o Humano!', 150, 200);
    noLoop();
  }
}